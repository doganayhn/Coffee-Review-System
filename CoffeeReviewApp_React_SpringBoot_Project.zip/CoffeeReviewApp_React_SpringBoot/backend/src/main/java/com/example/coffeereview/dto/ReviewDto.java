package com.example.coffeereview.dto;

public class ReviewDto {
  public Long id;
  public String author;
  public int rating;
  public String comment;
  public String date; // ISO string
}
